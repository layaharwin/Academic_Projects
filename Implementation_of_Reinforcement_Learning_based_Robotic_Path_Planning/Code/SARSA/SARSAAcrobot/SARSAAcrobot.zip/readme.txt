Acrobot Problem with SARSA 
Programmed in Matlab 
by:
 Jose Antonio Martin H. <jamartinh@fdi.ucm.es>

See Sutton & Barto book: Reinforcement Learning.





To run the demo use:



>> Demo <enter>



