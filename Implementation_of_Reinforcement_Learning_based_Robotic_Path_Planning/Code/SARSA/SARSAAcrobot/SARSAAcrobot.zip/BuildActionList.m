function [ actions ] = BuildActionList
%BuildActionList

%actions for the mountain car problem
actions = [-1.0 ; 0.0 ; 1.0];

