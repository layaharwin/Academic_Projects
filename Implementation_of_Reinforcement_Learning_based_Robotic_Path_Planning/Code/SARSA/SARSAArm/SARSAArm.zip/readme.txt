Reinforcement Learning Three-link planar robot with SARSA 
Programmed in Matlab 
by:
 Jose Antonio Martin H. <jamartinh@fdi.ucm.es>





To run the demo use:



>> Demo <enter>



