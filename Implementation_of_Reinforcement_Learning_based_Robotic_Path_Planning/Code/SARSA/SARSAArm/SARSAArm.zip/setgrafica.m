function setgrafica()

global grafica

grafica = ~grafica;