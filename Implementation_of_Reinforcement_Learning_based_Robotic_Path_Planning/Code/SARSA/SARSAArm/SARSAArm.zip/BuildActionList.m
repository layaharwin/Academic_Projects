function [ actions ] = BuildActionList
%BuildActionList

%actions for robot arm problem
actions  = [-5 ; -2 ;-1 ; 0 ; 1 ; 2 ; 5];
%actions = [-4 ;-2 ;-1 ; 0 ; 1 ; 2 ; 4];
%actions = [-2 ;-1 ; 0 ; 1 ; 2];
%actions = [-1 ; 0 ; 1];

